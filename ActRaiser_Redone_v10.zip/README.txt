ActRaiser Redone v1.0
By RetchERezzed

Patch file: ActRaiser_Redone_v10.ips
Target ROM: ActRaiser (USA), clean unheadered SNES ROM
Required clean CRC32: EAC3358D
Required clean SHA-1: E8365852CC20178D42C93CD188A7AE9AF45369D7

SUMMARY
ActRaiser Redone is a quality-of-life patch for ActRaiser on SNES.
The patch makes maximum population practical while keeping city population growth natural.
Current population is not forced directly to maximum.

FEATURES
- Choose Your Own Path: all six lands can be selected for their first action stage from a fresh playthrough
- Fillmore remains the recommended first land for the normal difficulty curve
- Later lands can be much harder at a low Master level
- Second-stage and Death Heim progression remain normal
- Before a land's first action stage is cleared, that land shows 000 / 0000
- After that land's first action stage is cleared, the city denominator unlocks that land's Redone maximum
- Current population grows normally from the founders toward that city maximum
- Real action-stage scores remain unchanged
- Current population is not force-written to maximum
- Growth resources are kept high enough for maximum expansion
- Housing population math supports full city growth
- Support bottlenecks are reduced so Wheat and bridge routing do not permanently block max population
- Five valid Aitos and Marahna construction squares are enabled
- Normal SP, score, status, and menu numbers are left alone

CITY MAXIMUMS
Region       Redone Max
Fillmore          0914
Bloodpool         0874
Kasandora         0874
Aitos             0834
Marahna           0562
Northwall         0650

EXPECTED CITY DISPLAY
State                                      Display
Fresh land before Act I is cleared         000 / 0000
Fillmore after Act I                       002 / 0914
Bloodpool after Act I                      002 / 0874
Kasandora after Act I                      002 / 0874
Aitos after Act I                          002 / 0834
Marahna after Act I                        002 / 0562
Northwall after Act I                      002 / 0650

INSTALLATION
1. Start with a clean unheadered ActRaiser USA ROM matching CRC32 EAC3358D
2. Apply ActRaiser_Redone_v10.ips
3. Do not apply over any older Redone or CITYHUD test ROM

VALIDATION
- Clean ROM identity verified
- IPS round-trip from clean ROM passed
- HUD text stream preserved
- SP display preserved
- Score display preserved
- Current population store remains vanilla
- No forced current-population maximum write is installed
- Runtime check confirmed the R7 city max behavior working

Patched target CRC32: BD8D15DB
IPS SHA-256: 3de3906a8a3c67f820250da5be7e4cb190e5418a720e9b69030662e7ac54d844

SPECIAL THANKS
Special thanks to Motron Games for pointing out that Action Stage score affects max population.
https://www.youtube.com/@motrongames

BUG REPORTS
If there are any bugs, glitches or issues, please let me know.

No ROM is included.
