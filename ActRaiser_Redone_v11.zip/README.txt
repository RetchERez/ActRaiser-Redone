ActRaiser Redone v1.1

By RetchERezzed

Patch file: ActRaiser_Redone_v11.ips
Target ROM: ActRaiser (USA), clean unheadered SNES ROM
Required clean CRC32: EAC3358D
Required clean SHA-1: E8365852CC20178D42C93CD188A7AE9AF45369D7

SUMMARY
ActRaiser Redone is a quality-of-life patch for ActRaiser on SNES.

The patch makes maximum population practical while keeping city population growth natural. Current population is not forced directly to maximum from the start.

FEATURES
* Choose Your Own Path
* Practical Max Population
* Natural Population Growth
* Increased Housing Capacity
* City Max Display
* Expanded Aitos and Marahna Build Access
* Lower Terraforming Miracle Costs
* Population Overflow Clamp

FEATURE DETAILS
Choose Your Own Path
All six lands can be selected for Act 1 from a fresh playthrough.

Practical Max Population
Cities can naturally grow to their Redone maximums without Action Stage score, support routing, Wheat routing, or strict structure optimization permanently blocking max population.

Natural Population Growth
Current population still grows normally from the founders toward the city maximum. Current population is not forced directly to maximum from the start.

Increased Housing Capacity
All housing tiers, from shacks to mansions, use the same higher effective livable population per structure. This prevents structure limits from stranding a fully developed city below its Redone maximum.

City Max Display
A fresh land shows 000 / 0000 before Act 1 is cleared. After that land's Act 1 is cleared, the city display unlocks that land's Redone maximum.

Expanded Aitos and Marahna Build Access
Valid hidden construction squares in Aitos and Marahna are enabled so both lands can reach their Redone maximums.

Lower Terraforming Miracle Costs
Rain costs 15 SP, Sun costs 20 SP, and Earthquake costs 20 SP. Lightning and Wind remain unchanged.

Population Overflow Clamp
City population cannot exceed the displayed Redone maximum. For example, Fillmore cannot rise above 914.

CITY MAXIMUMS
* Fillmore: 0914
* Bloodpool: 0874
* Kasandora: 0874
* Aitos: 0834
* Marahna: 0562
* Northwall: 0650

EXPECTED CITY DISPLAY
* Fresh land before Act 1 is cleared: 000 / 0000
* Fillmore after Act 1: 002 / 0914
* Bloodpool after Act 1: 002 / 0874
* Kasandora after Act 1: 002 / 0874
* Aitos after Act 1: 002 / 0834
* Marahna after Act 1: 002 / 0562
* Northwall after Act 1: 002 / 0650

TERRAFORMING MIRACLE COSTS
* Lightning: 10 SP
* Rain: 15 SP
* Sun: 20 SP
* Wind: 80 SP
* Earthquake: 20 SP

CHANGELOG
v1.1
* Lowered Rain cost from 20 SP to 15 SP
* Lowered Sun cost from 30 SP to 20 SP
* Lowered Earthquake cost from 160 SP to 20 SP
* Kept Lightning and Wind costs unchanged
* Increased effective housing capacity so structure limits cannot strand cities below their Redone maximums
* Added a city population overflow clamp so cities cannot exceed their displayed Redone maximum
* Rebased from the working v1.0 behavior

v1.0
* Added Choose Your Own Path
* Added practical max-population behavior
* Added natural city max display
* Added equalized housing capacity across all house tiers
* Added expanded Aitos and Marahna build access

INSTALLATION
1. Start with a clean unheadered ActRaiser USA ROM matching CRC32 EAC3358D
2. Apply ActRaiser_Redone_v11.ips
3. Do not apply over v1.0, v1.1 test builds, v1.2 test builds, older Redone builds, or CITYHUD test ROMs

VALIDATION
* Clean ROM identity verified
* IPS round-trip from clean ROM passed
* v1.0 working city max display retained
* Miracle cost changes applied
* Effective housing capacity increased
* Population overflow clamp installed
* Current population is not forced directly to maximum from the start
* No ROM is included

Patched target CRC32: 1D8A8C5F
IPS SHA-256: 1a82acf08aed2029f358ee9fa9d816aac75fc1cee3833159a5592a8a1c43093c

SPECIAL THANKS
Special thanks to Motron Games for pointing out that Action Stage score affects max population.
https://www.youtube.com/@motrongames

BUG REPORTS
Report any bugs, glitches, or issues.
