ActRaiser Redone v2.0
By RetchERezzed

GAME SUMMARY
ActRaiser is a Super Nintendo action and simulation game where the player alternates between side-scrolling action stages and town-building sequences. The Master defeats monsters directly in action stages, then guides towns through growth, miracles, road planning, lair sealing, and regional story events.

ActRaiser Redone v2.0 keeps the original game structure while making region choice and maximum population more practical. Players can choose any normal region for Act I from a fresh playthrough, and later-region action stages receive route-aware balance help when selected early.

FEATURE LIST
* Choose Your Path
* Practical Max Population
* Redone Max Population Caps
* Extra Valid Construction Squares
* Flexible Town Planning
* Lower Miracle Costs
* Dynamic Act Balance
* Enemy Hit-Count Scaling
* Boss Durability Retune
* Incoming Damage Scaling
* Enemy Density and Harasser Pressure Scaling

FEATURE DETAILS

CHOOSE YOUR PATH
All six normal regions are available for Act I from a fresh playthrough. Fillmore remains the recommended first region for the original difficulty curve, but players can start elsewhere.

Act II and Death Heim progression remain tied to normal game progress.

PRACTICAL MAX POPULATION
Town population goals are made practical without old score grinding or exact support routing. Score still exists and action-stage play remains part of the game.

Population display behavior uses Redone town caps where appropriate. Redone supports a world total of 4,708 after the added valid construction squares.

REDONE MAX POPULATION CAPS
Region       Vanilla Max   Redone Max
Fillmore           914           914
Bloodpool          874           874
Kasandora          874           874
Aitos              802           834
Marahna            538           562
Northwall          650           650
-------------------------------------
World Total      4,652         4,708

EXTRA VALID CONSTRUCTION SQUARES
Aitos gains three selectable construction squares:
[3,3], [4,4], [5,6]

Marahna gains two selectable construction squares:
[2,2], [6,2]

These are valid construction squares already present in the original game data.

FLEXIBLE TOWN PLANNING
Building Direction is less restrictive while still respecting real terrain and obstacles. Roads still use ActRaiser's normal construction behavior. Bridges remain permanent supporting structures. The original town structure storage behavior remains in place.

LOWER MIRACLE COSTS
Rain:       15 SP
Sun:        20 SP
Earthquake: 20 SP
Lightning: 10 SP unchanged
Wind:       80 SP unchanged

DYNAMIC ACT BALANCE
The balance system compares the act's normal route position against the player's current route position. Late regions receive stronger help when chosen early. Normal-route and late-route play keep their intended pressure.

Fillmore first keeps its original tutorial pacing. Northwall first receives the strongest early-route adjustment. Northwall late keeps full late-game pressure.

ENEMY HIT-COUNT SCALING
HP1 enemies remain one-hit enemies. HP2, HP3, and HP4 enemies can require fewer hits when a late region is played early. Higher-HP targets using the covered enemy HP subtraction path receive route-aware player damage scaling.

The Northwall first-pick gargoyle/statue one-hit result is retained.

BOSS DURABILITY RETUNE
High-HP boss-class targets keep more durability than the prior v2.0 balance candidate. Late-region bosses are still helped when selected early, but the extra high-HP bonus is capped lower so Northwall first-route boss fights do not collapse too quickly.

INCOMING DAMAGE SCALING
Enemy contact damage is reduced when a late region is played early. Covered object and effect damage paths also receive route-aware damage scaling.

Damaging objects keep a minimum damage value of 1. Zero-damage objects remain zero-damage.

ENEMY DENSITY AND HARASSER PRESSURE SCALING
Generic enemy initialization uses route-aware density scaling for eligible ordinary low-stat enemies when late regions are selected early. This keeps the pressure reduction tied to enemy setup instead of forcing an unsafe global onscreen object filter.

Northwall picked first receives the strongest eligible density reduction. Northwall picked late keeps full enemy density. Fillmore picked first keeps full enemy density.

STAGE PRESSURE USED FOR TUNING
Fillmore Act I: Bee, Bird, Ape, Goblin, Tree Man
Fillmore Act II: Cave Troll, Death Orb, Demon Mouth, Maggot, Skeltous, Troll, Zombee
Bloodpool Act I: Blood Bird, Flyfish, Lizard Knight, Rock Thrower
Bloodpool Act II: Electmachine, Flying Goblin, Gargoyle Statue, Ghosthead, Goblin, Red Slime, Skeltmon, Spear Goblin, Spike Machine
Kasandora Act I: Cactus, Fireman, Goblin, Flying Goblin, Sand Flower, Scorbee, Scorman, Spear Goblin
Kasandora Act II: Acid Droplet, Bird God, Mummy, Pharohead, Red Bird God, Visp
Aitos Act I: Air Fiend, Black Bird, Black Rock Thrower, Lava Ball, Roc, Rock Hand, Rock Thrower, Skull
Aitos Act II: Archer, Dragon Mouth, Fireball, Fire Eye, Gas Eye, Red Flying Goblin, Red Goblin
Marahna Act I: Headless Spear Man, Island Bat, Living Column, Poletrap, Purple Living Column, Swamp Jelly, Tribal Native
Marahna Act II: Death, Orb, Serpent Man, Skull Head, Spike Platform, Stone Mouth, Wyrm
Northwall Act I: Eyeball, Ice Cube, Icicle, Snow Bat, Snow Gargoyle Statue, Snowman
Northwall Act II: Axeman, Blue Bubble, Carrier Eagle, Gold Bubble, Green Bubble, Snowman, Tree Sap, Wisp, Worm

PROGRESSION COMPATIBILITY
Vanilla permanent Master HP progression is preserved. Sources of Life remain meaningful. Population rewards remain meaningful. Town, lair, population, score, item, and boss data remain intact.

INSTRUCTIONS

PACKAGE CONTENTS
* ActRaiser_Redone_v20.ips
* README.txt

REQUIRED CLEAN ROM
ActRaiser (USA), clean and unheadered
Size: 1,048,576 bytes
CRC32: EAC3358D
SHA-1: E8365852CC20178D42C93CD188A7AE9AF45369D7

STANDARD INSTALL
1. Start with a clean, unheadered ActRaiser (USA) ROM
2. Confirm the clean ROM CRC32 is EAC3358D
3. Apply ActRaiser_Redone_v20.ips with an IPS patcher
4. Name the patched ROM however you like
5. Confirm the finished ROM CRC32 is CE84AED6
6. Start a new game for the cleanest balance and population validation

PATCHING NOTES
* This package includes the standard Redone v2.0 patch only
* Apply the IPS to a clean USA ROM, not to an older Redone ROM
* ROM files are not included

EMULATOR NOTE
BSNES is the recommended compatibility baseline for testing and play.
Treat Snes9x results as secondary for this ROM.

RECOMMENDED PLAYTEST CHECKS
* Northwall first: gargoyle/statue dies in one hit
* Northwall first: eligible ordinary enemy pressure feels reduced
* Northwall late: full enemy density and danger are restored
* Fillmore first: tutorial pacing remains normal
* Bosses appear in all tested acts
* Items remain obtainable in all tested acts
* Population targets remain reachable
* Northwall boss durability feels firmer than the prior v2.0 candidate
* Northwall Act I clear returns to town/simulation without graphics corruption

TECHNICAL

TARGET ROM
ActRaiser (USA), clean and unheadered
Mapping: LoROM
ROM size: 8 Mb / 1 MiB
CRC32: EAC3358D
SHA-1: E8365852CC20178D42C93CD188A7AE9AF45369D7

PATCHED RESULT
Standard Redone v2.0 CRC32: CE84AED6

ROUTE BALANCE MODEL
The balance model uses the difference between the act's normal route position and the player's current route position. A larger early-route gap applies stronger help to enemy hit count, incoming damage, and ordinary enemy pressure.

Normal route slots used by the scaler:
Fillmore Act I: 1
Fillmore Act II: 2
Bloodpool Act I: 3
Bloodpool Act II: 4
Kasandora Act I: 5
Kasandora Act II: 6
Aitos Act I: 7
Aitos Act II: 8
Marahna Act I: 9
Marahna Act II: 10
Northwall Act I: 11
Northwall Act II: 12

Vanilla reference-level curve used for region scaling:
Fillmore: 1
Bloodpool: 2
Kasandora: 4
Aitos: 6
Marahna: 8
Northwall: 10

VERIFICATION
* Clean target identity verified
* Standard IPS applies directly to the clean USA ROM: PASS
* Finished standard CRC32 verified: CE84AED6
* SNES checksum and complement verified: PASS
* Generic action-object HP and damage initialization hook present: PASS
* Hardcoded HP2 initialization hook present: PASS
* Shared enemy HP subtraction hook present: PASS
* Boss durability retune present: PASS
* Incoming object/effect damage hook present: PASS
* Generic enemy-density gate present: PASS
* Unsafe active onscreen density gate removed: PASS
* Sword-clearable projectile changes are not included

THANKS
Patch by RetchERezzed
Special thanks to Motron Games for pointing out the maximum-population issue and destroyed-house behavior in his ActRaiser review
Technical reference material included The_Admiral's ActRaiser Maximum Population Guide, Data Crystal's ActRaiser ROM/RAM documentation, RPGClassics ActRaiser monster data, SNESMaps ActRaiser action maps, and TASVideos ActRaiser memory documentation
Credit also to the wonderful RetroGamingTalk community
